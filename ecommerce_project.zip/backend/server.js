const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');
const fs = require('fs');

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;

// Uploads static
const UPLOAD_DIR = process.env.UPLOAD_DIR || 'uploads';
if(!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive:true });
app.use('/uploads', express.static(path.join(__dirname, UPLOAD_DIR)));

// Models
const User = require('./models/User');
const Product = require('./models/Product');
const Category = require('./models/Category');

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/products', require('./routes/products'));

// Health
app.get('/api/health', (req,res)=> res.json({ok:true, time: new Date()}));

// Connect Mongo
mongoose.connect(process.env.MONGODB_URI, {useNewUrlParser:true, useUnifiedTopology:true})
  .then(async ()=>{
    console.log('MongoDB connected');
    // ensure admin user exists (initial seeding)
    const adminEmail = process.env.ADMIN_EMAIL;
    const adminPass = process.env.ADMIN_PASS;
    if(adminEmail && adminPass){
      const existing = await User.findOne({email: adminEmail});
      if(!existing){
        const u = new User({email: adminEmail, password: adminPass, role:'admin'});
        await u.save();
        console.log('Admin user created:', adminEmail);
      }
    }
    app.listen(PORT, ()=> console.log('Server listening on', PORT));
  })
  .catch(err=>{ console.error(err); process.exit(1); });
