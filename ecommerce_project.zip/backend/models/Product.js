const mongoose = require('mongoose');
const prodSchema = new mongoose.Schema({
  name:{type:String, required:true},
  desc:{type:String},
  cat:{type:String, required:true},
  price:{type:String},
  img:{type:String},
  createdAt:{type:Date, default:Date.now}
});
module.exports = mongoose.model('Product', prodSchema);
