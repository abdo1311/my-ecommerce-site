const mongoose = require('mongoose');
const catSchema = new mongoose.Schema({
  id:{type:String, required:true, unique:true},
  title:{type:String, required:true},
  desc:{type:String},
  img:{type:String}
});
module.exports = mongoose.model('Category', catSchema);
