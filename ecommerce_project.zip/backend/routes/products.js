const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const Product = require('../models/Product');
const Category = require('../models/Category');
const auth = require('../middleware/auth');

const uploadDir = process.env.UPLOAD_DIR || 'uploads';
const storage = multer.diskStorage({
  destination: function(req,file,cb){ cb(null, uploadDir); },
  filename: function(req,file,cb){ cb(null, Date.now() + path.extname(file.originalname)); }
});
const upload = multer({storage});

// Get all categories (seeded if empty)
router.get('/categories', async (req,res)=>{
  let cats = await Category.find();
  if(cats.length===0){
    // seed default categories
    const def = [
      {id:'laptops',title:'لابتوبات',desc:'أحدث أجهزة اللابتوب',img:'/uploads/default1.jpg'},
      {id:'accessories',title:'إكسسورات',desc:'شنط، شواحن، وفلاشة',img:'/uploads/default2.jpg'},
      {id:'gaming',title:'ألعاب',desc:'قطع للاعبين',img:'/uploads/default3.jpg'}
    ];
    cats = await Category.insertMany(def);
  }
  res.json(cats);
});

// Get products (with query cat or search)
router.get('/', async (req,res)=>{
  const q = req.query.q || '';
  const cat = req.query.cat || '';
  const filter = {};
  if(cat) filter.cat = cat;
  if(q) filter.$or = [ {name:new RegExp(q,'i')}, {desc:new RegExp(q,'i')} ];
  const prods = await Product.find(filter).sort({createdAt:-1});
  res.json(prods);
});

// Upload product (admin)
router.post('/', auth, upload.single('image'), async (req,res)=>{
  try{
    if(!req.user || req.user.role!=='admin') return res.status(403).json({message:'Not allowed'});
    const {name,desc,cat,price,imgUrl} = req.body;
    let img = imgUrl || '';
    if(req.file) img = '/' + req.file.path.replace(/\\/g, '/'); // corrected
    const p = new Product({name,desc,cat,price,img});
    await p.save();
    res.json(p);
  }catch(err){
    console.error(err);
    res.status(500).json({message:'Server error'});
  }
});

// Update product
router.put('/:id', auth, upload.single('image'), async (req,res)=>{
  try{
    if(!req.user || req.user.role!=='admin') return res.status(403).json({message:'Not allowed'});
    const id = req.params.id;
    const {name,desc,cat,price,imgUrl} = req.body;
    const update = {name,desc,cat,price};
    if(req.file) update.img = '/' + req.file.path.replace(/\\/g, '/');
    else if(imgUrl) update.img = imgUrl;
    const p = await Product.findByIdAndUpdate(id, update, {new:true});
    res.json(p);
  }catch(err){
    console.error(err);
    res.status(500).json({message:'Server error'});
  }
});

// Delete
router.delete('/:id', auth, async (req,res)=>{
  try{
    if(!req.user || req.user.role!=='admin') return res.status(403).json({message:'Not allowed'});
    await Product.findByIdAndDelete(req.params.id);
    res.json({ok:true});
  }catch(err){
    console.error(err);
    res.status(500).json({message:'Server error'});
  }
});

module.exports = router;
