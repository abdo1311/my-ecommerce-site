const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const secret = process.env.JWT_SECRET || 'notverysecret';

// login
router.post('/login', async (req,res)=>{
  const {email, password} = req.body;
  if(!email||!password) return res.status(400).json({message:'Missing'});
  const user = await User.findOne({email});
  if(!user) return res.status(401).json({message:'Invalid'});
  const ok = await user.comparePassword(password);
  if(!ok) return res.status(401).json({message:'Invalid'});
  const token = jwt.sign({id:user._id, role:user.role}, secret, {expiresIn:'7d'});
  res.json({token, user:{email:user.email, role:user.role}});
});

module.exports = router;
