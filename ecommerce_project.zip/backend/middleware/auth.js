const jwt = require('jsonwebtoken');
const User = require('../models/User');
const secret = process.env.JWT_SECRET || 'notverysecret';

module.exports = async function(req,res,next){
  const auth = req.headers.authorization;
  if(!auth) return res.status(401).json({message:'No token'});
  const token = auth.split(' ')[1];
  try{
    const payload = jwt.verify(token, secret);
    req.user = await User.findById(payload.id).select('-password');
    next();
  }catch(e){ res.status(401).json({message:'Invalid token'}) }
}
