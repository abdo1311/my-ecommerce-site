Project: Ecommerce frontend + backend (demo)

Backend:
- Node.js + Express + MongoDB (mongoose)
- To run:
  1. cd backend
  2. cp .env.example .env  (edit values if needed)
  3. npm install
  4. npm run dev
- MongoDB: use local or Atlas. Update MONGODB_URI in .env

Frontend:
- Static single-file SPA at frontend/index.html
- Open file directly or serve as static site. It uses localStorage for products by default.
- To connect to backend, set API_BASE in the frontend script to your backend URL.

I've packaged the full project below as a zip file.
